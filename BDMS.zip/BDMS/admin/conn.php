<?php
$conn=mysqli_connect("localhost","root","","blood_bank_database") or die("Connection error");
?>
