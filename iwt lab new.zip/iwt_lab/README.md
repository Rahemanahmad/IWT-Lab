IWT LAB Works

It contain week 1 to week 6 works in different folders.

BDMS: Bloodbank and Donation Management system 
  This lab project using php and xamp (backend) 
